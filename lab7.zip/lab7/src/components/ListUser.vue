<template>
  <ul v-if="users.length">
    <li v-for="(user, index) in users" :key="index">
      <p>{{ user.name }}</p>
      <p>{{ user.lastName }}</p>
    </li>
  </ul>
  <p v-else>Empty</p>
</template>

<script>
export default {
  props: {
    users: {
      type: Array,
      required: true,
    },
  },
};
</script>

<style></style>
