<template>
  <form class="modal-form" @submit.prevent>
    <p class="modal-text">
      <b>Registration</b>
    </p>

    <label class="form-description">
      <span class="form-description-text-name">Name</span>
      <div class="form-input-wrapper">
        <input
          v-model="name"
          class="form-input"
          type="text"
          pattern="^[a-zA-Zа-яА-Я]+"
          minlength="3"
          required
        />
      </div>
      <small class="error-message" v-if="errors.name">{{ errors.name }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text-name">Last Name</span>
      <div class="form-input-wrapper">
        <input
          v-model="lastName"
          class="form-input"
          type="text"
          pattern="^[a-zA-Zа-яА-Я]+"
          minlength="3"
          required
        />
      </div>
      <small class="error-message" v-if="errors.lastName">{{
        errors.lastName
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text-name">Middle Name</span>
      <div class="form-input-wrapper">
        <input
          v-model="middleName"
          class="form-input"
          type="text"
          pattern="^[a-zA-Zа-яА-Я]+"
          minlength="3"
          required
        />
      </div>
      <small class="error-message" v-if="errors.middleName">{{
        errors.middleName
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Email</span>
      <div class="form-input-wrapper">
        <input v-model="email" class="form-input" type="email" required />
      </div>
      <small class="error-message" v-if="errors.email">{{
        errors.email
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Phone</span>
      <div class="form-input-wrapper">
        <input
          v-model="phone"
          v-mask="'+38(###) ###-##-##'"
          class="form-input"
          type="text"
          placeholder="+38(0__) -___-__-__"
          required
        />
      </div>
      <small class="error-message" v-if="errors.phone">{{
        errors.phone
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Password</span>
      <div class="form-input-wrapper">
        <input v-model="password" class="form-input" type="password" required />
      </div>
      <small class="error-message" v-if="errors.password">{{
        errors.password
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Date of Birth</span>
      <div class="form-input-wrapper">
        <input v-model="dob" class="form-input" type="date" required />
      </div>
      <small class="error-message" v-if="errors.dob">{{ errors.dob }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Group</span>
      <div class="form-input-wrapper">
        <select v-model="group" class="form-input" required>
          <option value="">Select a group</option>
          <option value="IA-31">IA-31</option>
          <option value="IA-32">IA-32</option>
          <option value="IA-33">IA-33</option>
          <option value="IA-34">IA-34</option>
        </select>
      </div>
      <small class="error-message" v-if="errors.group">{{
        errors.group
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Upload Document</span>
      <div class="form-input-wrapper">
        <input
          class="form-input"
          type="file"
          accept=".pdf,.jpg,.png"
          required
        />
      </div>
      <small class="error-message" v-if="errors.document">{{
        errors.document
      }}</small>
    </label>

    <label class="form-description">
      <span class="form-description-text">Gender</span>
      <div class="form-input-wrapper">
        <label>
          <input type="radio" v-model="gender" value="Male" required /> Male
        </label>
        <label>
          <input type="radio" v-model="gender" value="Female" /> Female
        </label>
      </div>
      <small class="error-message" v-if="errors.gender">{{
        errors.gender
      }}</small>
    </label>

    <Button
      color="#4682b4"
      type="submit"
      @click="submitForm"
      class="form-btn-send"
      >Send</Button
    >
  </form>
</template>

<script>
import { mask } from "vue-the-mask";
import Button from "@/views/Button.vue";

export default {
  components: {
    Button,
  },
  directives: {
    mask,
  },
  data() {
    return {
      name: "",
      lastName: "",
      middleName: "",
      email: "",
      phone: "",
      password: "",
      dob: "",
      group: "",
      document: null,
      gender: "",
      errors: {},
    };
  },
  methods: {
    validateFields() {
      this.errors = {};
      if (!this.name) this.errors.name = "Name is required.";
      if (!this.lastName) this.errors.lastName = "Last name is required.";
      if (!this.middleName) this.errors.middleName = "Middle name is required.";
      if (!this.email) this.errors.email = "Email is required.";
      if (!this.phone) this.errors.phone = "Phone is required.";
      if (!this.password) this.errors.password = "Password is required.";
      if (!this.dob) this.errors.dob = "Date of birth is required.";
      if (!this.group) this.errors.group = "Group is required.";
      if (!this.document) this.errors.document = "Document is required.";
      if (!this.gender) this.errors.gender = "Gender is required.";
      return Object.keys(this.errors).length === 0;
    },
    submitForm() {
      console.log(1);

      const newUser = {
        name: this.name,
        lastName: this.lastName,
        middleName: this.middleName,
        email: this.email,
        phone: this.phone,
        password: this.password,
        dob: this.dob,
        group: this.group,
        gender: this.gender,
      };

      this.$emit("addUser", newUser);

      console.log("newUser", newUser);

      console.log(2);
    },
  },
};
</script>

<style scoped>
.modal-form {
  width: 350px;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-input-wrapper {
  position: relative;
}

.form-input {
  width: 100%;
  padding: 8px;
  font-size: 14px;
}

.error-message {
  color: red;
  font-size: 12px;
}
</style>
