<template>
  <p>{{ this.user.name }}</p>
  <p>{{ this.user.lastName }}</p>
</template>

<script>
export default {
  data() {
    return {};
  },
  props: {
    user: {
      type: Object,
      required: true,
    },
  },
};
</script>

<style></style>
